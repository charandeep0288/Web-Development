import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import Test from "./Test"

ReactDOM.render(<App />, document.getElementById("root"));
